Mahakal Light Sale & Service - Android Studio Project

यह ZIP तैयार Android Studio प्रोजेक्ट है, APK फ़ाइल नहीं।

APK बनाने के लिए:
1. Android Studio में इस पूरे फ़ोल्डर को Open करें।
2. Gradle Sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा।

ध्यान दें:
- ऐप की HTML/Manifest/Service Worker फाइलें assets में रखी गई हैं।
- Firebase modules और WhatsApp link के लिए इंटरनेट आवश्यक है।
- यह मौजूदा Firebase डेटा को मिटाता या बदलता नहीं है।
- APK इस ZIP में पहले से शामिल नहीं है; उसे Android SDK/Android Studio से compile करना होगा।


ICON UPDATE (04-11-2026)
Mahakal + bulb + SAHU launcher icon added in all five mipmap density folders.
AndroidManifest.xml now points to @mipmap/ic_launcher and @mipmap/ic_launcher_round.
